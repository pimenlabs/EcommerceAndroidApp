package com.ecommerce.app;

public class NavDrawer_Constant {
	public static final String ABOUT = "file:///android_asset/about.html";
	public static final String EMAIL = "hahaha@gmail.com";

	
	public static final String[] ARTICLE_TITLES_PERTAMA = { 
			"Product",
			"Cart", 
			"Checkout", 
			"Profile",
			"Information",
			"About",
			"Share",
			"Contact"
	};
	
	public static final int[] ARTICLE_THUMBNAILS_PERTAMA = {
			R.drawable.menu1, 
			R.drawable.menu2, 
			R.drawable.menu3,
			R.drawable.menu4, 
			R.drawable.menu5,
			R.drawable.menu6,
			R.drawable.menu7,
			R.drawable.menu8			
	};


}