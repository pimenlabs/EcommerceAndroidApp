package com.ecommerce.app;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class NavDrawer_Fragment extends Fragment {

	String[] heads = NavDrawer_Constant.ARTICLE_TITLES_PERTAMA;
	int[] thumbnails = NavDrawer_Constant.ARTICLE_THUMBNAILS_PERTAMA;
	int status = 1;

	public NavDrawer_Fragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.fragment_list, container,
				false);
		GridView lv = (GridView) rootView.findViewById(R.id.gridView1);

		CAdapter adapter = new CAdapter(getActivity(), R.layout.fragment_list_item, heads);
		lv.setAdapter(adapter);

		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (position==0){
					startActivity(new Intent(getActivity(), CategoryList.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==1){
					startActivity(new Intent(getActivity(), YourOrder.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==2){
					startActivity(new Intent(getActivity(), Checkout.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==3){
					startActivity(new Intent(getActivity(), Profile.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==4){
					startActivity(new Intent(getActivity(), Information.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==5){
					startActivity(new Intent(getActivity(), About.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
				else if (position==6){
					Intent sendInt = new Intent(Intent.ACTION_SEND);
					sendInt.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
					sendInt.putExtra(Intent.EXTRA_TEXT, "E-Commerce Android App\n\""+getString(R.string.app_name)+"\" \nhttps://play.google.com/store/apps/details?id="+getActivity().getPackageName());
					sendInt.setType("text/plain");
					startActivity(Intent.createChooser(sendInt, "Share"));
				}
				else {
					startActivity(new Intent(getActivity(), Contact_Us.class));
					getActivity().overridePendingTransition (R.anim.open_next, R.anim.close_next);
				}
			}
		});

		return rootView;
	}

	public class CAdapter extends ArrayAdapter<String> {
		Context c;

		public CAdapter(Context context, int textViewResourceId,
				String[] objects) {
			super(context, R.layout.fragment_list_item, heads);
			c = context;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) c
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View row = inflater.inflate(R.layout.fragment_list_item, parent, false);
			ImageView iv = (ImageView) row.findViewById(R.id.thumbnails);
			TextView tv = (TextView) row.findViewById(R.id.name);
			tv.setText(heads[position]);
			iv.setImageResource(thumbnails[position]);

			return row;
		}
	}
}
