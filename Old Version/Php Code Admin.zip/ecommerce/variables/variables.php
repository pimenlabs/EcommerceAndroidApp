<?php
	// database configuration
	$host ="localhost";
	$user ="root";
	$pass ="";
	$database = "ecommerce";
	$connect = new mysqli($host, $user, $pass,$database) or die("Error : ".mysql_error());
	
	// access key to access API
	$access_key = "12345";
	
	// google play url
	$gplay_url = "https://play.google.com/store/apps/details?id=your.package.com";
	
	// email configuration
	$admin_email = "";
	$email_subject = "";
	$change_message = "You have change your admin info such as email and or password.";
	$reset_message = "Your new password is ";
	
	// reservation notification configuration
	$reservation_subject = "";
	$reservation_message = "Ada pemesanan baru, silakan cek di halaman administrator.";
	
	// copyright
	$copyright = "";
?>