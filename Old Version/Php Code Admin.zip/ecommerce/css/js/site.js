$(function() {
  // start the icon carousel
  $('#icon-carousel').carousel({
    interval: 5000
  });
});
