<?php
	include($_SERVER['DOCUMENT_ROOT'].'/ecommerce/variables/variables.php');
	$connect->close();
?>