<?php include('variables/variables.php'); ?>
<div id="footer">
</div>